// Naming this your main package, if this isn't named main, code won't run
package main

// Importing the fmt package to print to terminal
import "fmt"

// defining main function
func main() {
  fmt.Printf("hello, world\n")
}
