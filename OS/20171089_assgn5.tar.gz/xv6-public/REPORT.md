# ASSIGNMENT 6

## QUESTION 2 REPORT

> `ps` syscall shows the `name`, `pid`, `state` and `priority` of all the process.
> All processes have an initial priority of `60`
>Initial output of `ps` is:
>| Name    | Pid   | state    | Priority|
>|---------|-------|----------|---------|
>| init    | 1     | SLEEPING | 60      |
>| sh      | 2     | SLEEPING | 60      |
>| ps      | 3     | RUNNING  | 60      |
>Two processes with same priority have been created with command `test 1000 &; test 1000 &`
>| name  |  pid    |   state     | Priority  |
>|-------|---------|-------------|-----------|
>| init  |    1    |  SLEEPING   | 60        |
>| sh    |    2    |  SLEEPING   | 60        |
>| test  |    12   |  RUNNABLE   | 60        |
>| test  |    7    |  SLEEPING   | 60        |
>| test  |    6    |  SLEEPING   | 60        |
>| test  |    9    |  RUNNING    | 60        |
>| ps    |    13   |  RUNNING    | 60        |
> We then set the priority of `process 7` to `80` by executing `set_priority 9 80`
> We try ps again and we see 2 changes
>| name  |  pid    |   state     | Priority  |
>|-------|---------|-------------|-----------|
>| init  |    1    |  SLEEPING   | 60        |
>| sh    |    2    |  SLEEPING   | 60        |
>| test  |    12   |  RUNNING    | 60        |
>| test  |    7    |  SLEEPING   | 60        |
>| test  |    6    |  SLEEPING   | 60        |
>| test  |    9    |  RUNNABLE   | 80        |
>| ps    |    13   |  RUNNING    | 60        |
>
> 1. priority of `process 9` has been made `80`
> 2. `process 9` has been made `RUNNABLE` while `process 12` is set to `RUNNING`
>
>Thus we know that our priority based shceduler is working properly

### COMPARISON BETWEEN ROUND-ROBIN AND PRIORITY SCHEDULING

> - In round-robin all processes are scheduled in a circular manner. Whereas in priority scheduling a process is preemped if a higher process with higher priority comes and rescheduling is done.
> - In priority scheduling starvation takes place ie., lower priorities are not allocated CPU until all the processes with higher priority are added.  
