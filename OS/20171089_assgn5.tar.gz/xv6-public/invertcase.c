#include "types.h"
#include "stat.h"
#include "user.h"

char buf[512];

int
main(int argc, char *argv[])
{
  int i;

  if(argc <= 1){
    printf(1,"No Input String");
    exit();
  }

  for(i = 1; i < argc; i++){
    for(int j=0;argv[i][j]!='\0';j++)
    {
      if(argv[i][j]>='A' && argv[i][j]<='Z')
      {
        printf(1,"%c",argv[i][j]+32);
      }
      else if(argv[i][j]>='a' && argv[i][j]<='z')
      {
        printf(1,"%c",argv[i][j]-32);
      }
      else
      {
        printf(1,"%c",argv[i][j]);
      }
    }
    printf(1," ");
  }
  printf(1,"\n");
  exit();
}
